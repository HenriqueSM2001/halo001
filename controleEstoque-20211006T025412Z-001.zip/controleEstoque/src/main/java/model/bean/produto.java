/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.bean;

/**
 *
 * @author Aluno
 */
public class produto {
    private String login;
    private String senha;
    private int IDmarca;
    private String descricao;
    private int IDcor;
    private int codigo;
    private Double preco;

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public int getIDmarca() {
        return IDmarca;
    }

    public void setIDmarca(int IDmarca) {
        this.IDmarca = IDmarca;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public int getIDcor() {
        return IDcor;
    }

    public void setIDcor(int IDcor) {
        this.IDcor = IDcor;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public Double getPreco() {
        return preco;
    }

    public void setPreco(Double preco) {
        this.preco = preco;
    }
    
}
   