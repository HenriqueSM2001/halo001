/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.bean;


import connection.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.bean.cor;

/**
 *
 * @author 
 */
public class corDAO {

  
    public List<cor> read() {

        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<cor> cores = new ArrayList<>();

        try {
            stmt = con.prepareStatement("SELECT ID,cor FROM cor");
            rs = stmt.executeQuery();

            while (rs.next()) {

                cor c = new cor();

                c.setID(rs.getInt("ID"));
                c.setCor(rs.getString("cor"));
                cores.add(c);
                
            }

        } catch (SQLException ex) {
            Logger.getLogger(ProdutoDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }

        return cores;

    }
    public List<cor> readForDesc(String cor) {

        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<cor> produtos = new ArrayList<>();

        try {
            stmt = con.prepareStatement("SELECT * FROM cor WHERE cor LIKE ?");
            stmt.setString(1, "%"+cor+"%");
            
            rs = stmt.executeQuery();

            while (rs.next()) {

                cor produto = new cor();

               produto.setID(rs.getInt("ID"));
                produto.setCor(rs.getString("cor"));
             
                produtos.add(produto);
            }

        } catch (SQLException ex) {
            Logger.getLogger(ProdutoDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }

        return produtos;

    }

    public void update(cor p) {

        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("UPDATE cor SET cor = ? ,ID = ?");
            stmt.setString(1, p.getCor());
            stmt.setInt(2, p.getID());
            
            stmt.executeUpdate();

            //JOptionPane.showMessageDialog(null, "Atualizado com sucesso!");
        } catch (SQLException ex) {
            //JOptionPane.showMessageDialog(null, "Erro ao atualizar: " + ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }

    }
 
}
