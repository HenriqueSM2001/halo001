/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.bean;

import connection.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Aluno
 */
public class saidaDAO {
    public List<saida> read() {

        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<saida> saidas = new ArrayList<>();

        try {
            stmt = con.prepareStatement("SELECT codigo,descricao FROM cadastro");
            rs = stmt.executeQuery();

            while (rs.next()) {

                saida c = new saida();

                c.setCodigo(rs.getInt("codigo"));
                c.setDescricao(rs.getString("descricao"));
                saidas.add(c);               
            }

        } catch (SQLException ex) {
            Logger.getLogger(ProdutoDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }

        return saidas;

    }
      public void create(saida i) {

                    try{
                        Connection con = ConnectionFactory.getConnection();
                        PreparedStatement stmt = null;

                        stmt = con.prepareStatement("INSERT INTO historico (codigo,descricao,operacao,quantidade) VALUES (?,?,?,?)");
                     
                        stmt.setInt(1,i.getCodigo());
                        stmt.setString(2,i.getDescricao());
                        stmt.setString(3,i.getOperacao());
                        stmt.setInt(4,i.getQuantidade());
                        
                        stmt.execute();
                        } catch (SQLException ex){

                         Logger.getLogger(ProdutoDAO.class.getName()).log(Level.SEVERE, null, ex);
                    }finally{
                        
                    }
      }
    
}
