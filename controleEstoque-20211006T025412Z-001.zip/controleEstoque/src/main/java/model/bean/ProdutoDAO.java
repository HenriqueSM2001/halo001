/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.bean;

import connection.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.bean.cor;
/**
 *
 * @author Aluno
 */
public class ProdutoDAO {
    
            public void create(produto p) {

                    try{
                        Connection con = ConnectionFactory.getConnection();
                        PreparedStatement stmt = null;

                        stmt = con.prepareStatement("INSERT INTO cadastro (codigo,descricao,IDmarca,preco,IDcor) VALUES (?,?,?,?,?)");

                        stmt.setInt(1,p.getCodigo());
                        stmt.setString(2,p.getDescricao());
                        stmt.setInt(3,p.getIDmarca());
                        stmt.setDouble(4,p.getPreco());
                        stmt.setInt(5,p.getIDcor());


                        stmt.execute();
                        } catch (SQLException ex){

                         Logger.getLogger(ProdutoDAO.class.getName()).log(Level.SEVERE, null, ex);
                    }finally{
                        
                    }
                  
      } 
            
            
            
}
